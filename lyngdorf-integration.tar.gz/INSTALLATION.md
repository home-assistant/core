# Lyngdorf Integration - Installation Instructions

## Installation Steps:

### 1. Extract the archive on your Home Assistant machine:

```bash
# Extract to your HA config directory
cd /config
tar -xzf lyngdorf-integration.tar.gz
```

This will create: `/config/custom_components/lyngdorf/`

### 2. Restart Home Assistant

### 3. Add Integration:
- Go to **Settings** → **Devices & Services**
- Click **+ Add Integration**
- Search for "Lyngdorf"
- Follow the setup wizard

## Requirements:
- Home Assistant 2026.1.3 or newer (requires Python 3.13.2+)
- Network access to your Lyngdorf device
- SSDP discovery enabled (or manual IP entry)

## Features:
- Automatic discovery via SSDP
- Media player control
- Zone B support
- Audio input selection
- Volume and trim controls
- Streaming source management

## Troubleshooting:

If the integration doesn't appear:
1. Check files are in `/config/custom_components/lyngdorf/`
2. Check Home Assistant logs for errors
3. Ensure your HA version is 2026.1.3+
4. Verify the `lyngdorf==0.3.7` Python package installs successfully

## Files Included:
- `__init__.py` - Main integration file
- `config_flow.py` - Configuration UI
- `const.py` - Constants
- `manifest.json` - Integration metadata
- `media_player.py` - Media player entity
- `number.py` - Number entities (trims)
- `select.py` - Select entities (sources, modes)
- `strings.json` - UI translations

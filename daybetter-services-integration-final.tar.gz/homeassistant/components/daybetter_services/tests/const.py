"""Constants for tests."""

DOMAIN = "daybetter_services"
CONF_USER_CODE = "user_code"
CONF_TOKEN = "token"
API_BASE_URL = "https://a.dbiot.org/daybetter/hass/api/v1.0/"

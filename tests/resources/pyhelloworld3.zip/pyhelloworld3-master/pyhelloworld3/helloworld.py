# -*- coding: ISO-8859-1 -*-
"""This module displays 'Hello world !'"""


def hello_world():
    print('Hello World !')
